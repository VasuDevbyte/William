BOT_TOKEN = "1455:AAE4qFS3nF-0Tn"
API_ID = 69
API_HASH = "e46b6c854d2bf580"
PHONE_NUMBER = "+910000000000" # Need for Helper Userbot
MAIN_CHATS = [-1001485393652]  # NOTE These are the chats where main functions of bot will work, like music downloading etc.
SUDO_USERS_ID = [51635132416, 1342121354245, 23452465243] # Sudo users have full access to everythin, don't trust anyone
LOG_GROUP_ID = -1001337393587
GBAN_LOG_GROUP_ID = -1001401678112
FERNET_ENCRYPTION_KEY = "iKMq0WZMnJKjMQxZWKtv-cplMuF_LoyshXj0XbTGGWM="
WELCOME_DELAY_KICK_SEC = 300
MONGO_DB_URI = "mongodb+srv://username:password@cluster0.ksiis.mongodb.net/YourDataBaseName?retryWrites=true&w=majority"


# NOTE Don't make changes below this line
ARQ_API_BASE_URL = "http://35.240.133.234:8000"
